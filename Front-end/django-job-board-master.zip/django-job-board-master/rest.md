

- Function Based Views  :
    - simple 
    - cusomize 
    - complex 


- Class Based Views : 
    - fast development
    - not complex 


- Viewsets : 
    - api -- [model + url] [CRUD]