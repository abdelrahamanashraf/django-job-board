 - frontend template
 - virtualenv : 
    - create 
    - activate [windowds : source ./scripts/activate]
    - pip install 
    - deactivate 

- upload project on github

- url : path 
- view : logic 
- models : db
- templates : frontend





Relations : 
    - One to many    [ user - posts ]   Foreginkey
    - Many to many   [ user - groups ]  
    - One to one  [ user - profile ]




static files : [frontend] images , css , javascript 
media files : [upload] images